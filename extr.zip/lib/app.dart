import 'package:flutter/material.dart';
import 'package:smgi_connect/features/aadhar/aadhaar_verification_screen.dart';
import 'package:smgi_connect/features/document/vault_screen.dart';
import 'package:smgi_connect/features/markscard/upload_marks_card_screen.dart';
import 'package:smgi_connect/features/splashscreen/splash_screen.dart';
import 'core/theme/app_theme.dart';

class SMGIApp extends StatelessWidget {
  const SMGIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SMGI Connect',
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
    );
  }
}