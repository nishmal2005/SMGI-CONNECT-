import 'package:flutter/material.dart';
import 'package:smgi_connect/model/dummy_documentmodel.dart';

class StatusWidget extends StatelessWidget {
  final DocumentStatus status;

  const StatusWidget({required this.status});

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case DocumentStatus.verified:
        return _text('Verified', const Color(0xFF2ECC71));

      case DocumentStatus.pending:
        return _text('Pending', const Color(0xFFF1C40F));

      case DocumentStatus.rejected:
        return _text('Rejected', const Color(0xFFE74C3C));

      case DocumentStatus.reupload:
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFFE74C3C),
            borderRadius: BorderRadius.circular(6),
          ),
          child: const Text(
            'Reupload',
            style: TextStyle(
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.w400,
            ),
          ),
        );
    }
  }

  Widget _text(String text, Color color) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: color,
      ),
    );
  }
}
