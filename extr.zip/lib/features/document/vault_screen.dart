import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/core/constants/app_text_styles.dart';
import 'package:smgi_connect/dummy/data.dart';
import 'package:smgi_connect/features/document/card_widget.dart';
import 'package:smgi_connect/features/navbar/bottom_nav_bar.dart';
import 'package:smgi_connect/shared/widgets/app_bar.dart';
import 'package:smgi_connect/shared/widgets/app_scaffold.dart';



class DocumentVaultScreen extends StatelessWidget {
  const DocumentVaultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return AppScaffold(
      bottomNavigationBar: const HomeBottomNav(),
      body: SafeArea(
      
        child: Column(
          children: [
            // ❗Same structure and spacing as HomeScreen
            const HomeAppBar(),

            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: size.width * .04, // Same responsive padding
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 20),

                      Text(
                        'Documents',
                        style: AppTextStyles.subtitle.copyWith(
                          fontSize: 22,
                          color: AppColors.black,
                        ),
                      ),

                      const SizedBox(height: 20),

                      ListView.separated(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: documents.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) =>
                            DocumentCard(item: documents[index]),
                      ),

                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
