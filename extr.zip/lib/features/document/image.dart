import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';


class DocumentImage extends StatelessWidget {
  final String image;

  const DocumentImage(this.image);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      width: 44,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Image.asset(
        image,
        fit: BoxFit.contain,
      ),
    );
  }
}
