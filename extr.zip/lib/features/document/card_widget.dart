import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/core/constants/app_text_styles.dart';
import 'package:smgi_connect/features/document/image.dart';
import 'package:smgi_connect/features/document/status_widgets.dart';
import 'package:smgi_connect/model/dummy_documentmodel.dart';



class DocumentCard extends StatelessWidget {
  final DocumentItem item;

  const DocumentCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Container(
      padding: EdgeInsets.all(size.width * 0.04),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          DocumentImage(item.image),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
            item.title,
            style: AppTextStyles.subtitle.copyWith(
              fontSize: 14,
              color: AppColors.black,
            ),
            
          ),
          ),
          StatusWidget(status: item.status),
        ],
      ),
    );
  }
}
