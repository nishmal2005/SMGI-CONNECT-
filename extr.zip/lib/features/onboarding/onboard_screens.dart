import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_text_styles.dart';
import 'package:smgi_connect/features/auth/screens/login_screen.dart';
import 'package:smgi_connect/features/onboarding/onboarding_model.dart';
import 'package:smgi_connect/shared/widgets/gap.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int currentPage = 0;

  final List<OnboardingData> data = [
    OnboardingData(
      image: 'assets/images/onboarding1.png',
      title: 'Digital admission\nmade easy',
      description:
          'Begin your journey with a clean, step-by-step admission system.',
    ),
    OnboardingData(
      image: 'assets/images/onboarding2.png',
      title: 'Apply Your\nReferral Code',
      description:
          'Enter your referral code to get exclusive admission benefits.',
    ),
    OnboardingData(
      image: 'assets/images/onboarding3.png',
      title: 'Complete Your\nPayment Safely',
      description: 'Quick, reliable, and fully protected payment processing.',
    ),
  ];

  void goToNext() {
    if (currentPage < data.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.ease,
      );
    } else {
      goToHome();
    }
  }

  void goToHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: PageView.builder(
        controller: _pageController,
        itemCount: data.length,
        onPageChanged: (index) => setState(() => currentPage = index),
        itemBuilder: (context, index) {
          final item = data[index];

          return Container(
            width: size.width,
            height: size.height,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(item.image),
                fit: BoxFit.cover,
              ),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.08),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// 🔹 Top spacing (374)
                  Gap(h: size.height * 0.50),

                  /// 🔹 Title
                  Text(item.title, style: AppTextStyles.headline),

                  /// 🔹 Space between title & description (20)
                  Gap(h: size.height * 0.025),

                  /// 🔹 Description
                  Text(item.description, style: AppTextStyles.body),

                  /// 🔹 Space before buttons (208)
                  Gap(h: size.height * 0.22),

                  /// 🔹 Bottom buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      /// Skip Button (hide on last page)
                      if (currentPage != data.length - 1)
                        TextButton(
                          onPressed: goToHome,
                          child: const Text(
                            'Skip',
                            style: AppTextStyles.button,
                          ),
                        )
                      else
                        const SizedBox(), // keeps spacing clean
                      /// Next / Get Started Button
                      TextButton(
                        onPressed: goToNext,
                        child: Text(
                          currentPage == data.length - 1
                              ? 'Get Started'
                              : 'Next',
                          style: AppTextStyles.button,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text('Home Screen', style: TextStyle(fontSize: 22))),
    );
  }
}
