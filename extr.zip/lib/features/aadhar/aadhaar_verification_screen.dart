import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/features/aadhar/card.dart';
import 'package:smgi_connect/shared/widgets/app_scaffold.dart';
import 'package:smgi_connect/shared/widgets/auth/gradient_button.dart';
import 'package:smgi_connect/shared/widgets/custom_input_field.dart';
import 'package:smgi_connect/shared/widgets/warning_popup.dart';
import '../../../core/constants/app_text_styles.dart';

class AadhaarVerificationScreen extends StatelessWidget {
  const AadhaarVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return AppScaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Back arrow aligned to edge
              IconButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => LeaveConfirmationDialog(
                      onLeave: () {
                        Navigator.pop(context); // close dialog
                        Navigator.pop(context); // go back page
                      },
                    ),
                  );
                },
                icon: const Icon(Icons.arrow_back, color: AppColors.accent),
              ),

              const SizedBox(height: 10),

              /// Main screen content begins after padding
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// Title
                    const Text(
                      "Aadhaar Verification",
                      style: TextStyle(
                        color: AppColors.black,
                        fontSize: 18,
                        fontWeight: FontWeight.w600, // semibold
                        fontFamily: "Poppins",
                      ),
                    ),
                    const SizedBox(height: 24),

                    /// Input Label
                    Text(
                      "Enter Aadhaar Number (12 Digits)",
                      style: AppTextStyles.body3.copyWith(
                        color: AppColors.black,
                        fontFamily: "Poppins",
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const SizedBox(height: 8),

                    /// Aadhaar TextField
                    const CustomInputField(hintText: "XXXX XXXX XXXX XXXX"),
                    const SizedBox(height: 24),

                    /// Upload Label
                    Text(
                      "Upload Aadhaar Card (Front/Back)",
                      style: AppTextStyles.body3.copyWith(
                        color: AppColors.black,
                        fontFamily: "Poppins",
                      ),
                    ),
                    const SizedBox(height: 12),

                    /// Upload Card
                    UploadCard(
                      height: 300,
                      width: screenWidth,
                      assetPath: "assets/images/download.png",
                    ),
                    const SizedBox(height: 40),

                    /// Continue Button
                    GradientButton(text: "Continue", onTap: () {}),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
