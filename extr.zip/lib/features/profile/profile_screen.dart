import 'package:flutter/material.dart';
import 'package:smgi_connect/shared/widgets/app_bar.dart';
import 'package:smgi_connect/shared/widgets/app_scaffold.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return SafeArea(
  
      child: AppScaffold(
        appBar: const PreferredSize(
          preferredSize: Size.fromHeight(60),
          child: HomeAppBar(),
        ),

        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: width * 0.05),
          child: Column(
            children: [
              /// ---- NAME CARD ----
              Container(
                height: 90,
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                padding: EdgeInsets.symmetric(horizontal: width * 0.04),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 8,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    /// USER IMAGE
                    Container(
                      height: 55,
                      width: 55,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFF0085FF),
                          width: 2,
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 6,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          "assets/images/person.jpeg",
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),

                    SizedBox(width: width * 0.04),

                    /// NAME TEXT
                    const Text(
                      "Cooper, Kristin",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF1A1A1A),
                      ),
                    ),
                  ],
                ),
              ),

              _buildProfileTile("My Account", context, isFirst: true),
              _buildProfileTile("Settings", context),
              _buildProfileTile("Help", context, isLast: true),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileTile(
    String title,
    BuildContext context, {
    bool isFirst = false,
    bool isLast = false,
  }) {
    final width = MediaQuery.of(context).size.width;

    return Container(
      height: 60,
      padding: EdgeInsets.symmetric(horizontal: width * 0.04),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(
          top: isFirst ? const Radius.circular(12) : Radius.zero,
          bottom: isLast ? const Radius.circular(12) : Radius.zero,
        ),
        border: Border.all(color: const Color(0xFFD1D1D1), width: 0.75),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF1A1A1A),
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
          ),
          const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.black),
        ],
      ),
    );
  }
}
