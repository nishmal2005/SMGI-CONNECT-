import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/features/document/vault_screen.dart';
import 'package:smgi_connect/features/homescreen/homecontent.dart';
import 'package:smgi_connect/features/navbar/nav_items.dart';
import 'package:smgi_connect/features/profile/profile_screen.dart';


class HomeBottomNav extends StatefulWidget {
  const HomeBottomNav({super.key});

  @override
  State<HomeBottomNav> createState() => _HomeBottomNavState();
}

class _HomeBottomNavState extends State<HomeBottomNav> {
  int selectedIndex = 0;

  final icons = const [
    LucideIcons.home,
    LucideIcons.fileText,
    LucideIcons.user, // 🟢 replace wallet if page not exists
    LucideIcons.creditCard, 
  ];

  final pages = const [
    HomeContent(),
    DocumentVaultScreen(),
    ProfileScreen(),
    ProfileScreen(), // temp, until real page is added
  ];
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    final navHeight = size.height * 0.075; // responsive height
    final padding = size.width * 0.04;
    final radius = size.width * 0.08;

    return Scaffold(
      body: pages[selectedIndex], // 👉 show selected page here
      bottomNavigationBar: Padding(
        padding: EdgeInsets.all(padding),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(radius),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              height: navHeight,
              decoration: BoxDecoration(
                color: AppColors.entirenavBg,
                borderRadius: BorderRadius.circular(radius),
                border: Border.all(color: Colors.white.withOpacity(0.18)),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.navBg,
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: List.generate(
                  icons.length,
                  (index) => NavItem(
                    icon: icons[index],
                    active: selectedIndex == index,
                    onTap: () {
                      setState(() => selectedIndex = index);
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
