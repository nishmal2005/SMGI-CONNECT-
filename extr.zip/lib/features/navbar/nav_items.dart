import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';


class NavItem extends StatelessWidget {
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  const NavItem({
    super.key,
    required this.icon,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 48,
        width: 64,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active
              ? const Color.fromARGB(255, 25, 14, 7).withOpacity(0.06)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: AppColors.navBg.withOpacity(0.06),
                    blurRadius: 8,
                  )
                ]
              : null,
        ),
        child: Icon(
          icon,
          size: 24,
          color: active
              ? AppColors.navSelected
              : AppColors.navNotSelected,
        ),
      ),
    );
  }
}