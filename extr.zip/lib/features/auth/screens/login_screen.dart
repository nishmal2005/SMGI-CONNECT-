import 'package:flutter/material.dart';
import 'package:smgi_connect/features/auth/screens/otp_screen.dart';
import '../../../shared/widgets/auth_background.dart';
import '../../../shared/widgets/gap.dart';
import '../../../shared/widgets/auth/gradient_button.dart';
import '../../../shared/widgets/auth/gradient_text_field.dart';
import '../../../core/constants/app_text_styles.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AuthBackground(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                /// 🔥 TOP SPACING (matches logo top: 134px)
                const Gap(h: 134),

                /// LOGO
                Hero(
                  tag: 'logo',
                  child: RichText(
                    text: const TextSpan(
                      children: [
                        TextSpan(text: 'SMGI ', style: AppTextStyles.logoGold),
                        TextSpan(
                          text: 'Connect',
                          style: AppTextStyles.logoWhite,
                        ),
                      ],
                    ),
                  ),
                ),

                /// GAP: 256 - (134 + 42) ≈ 80
                const Gap(h: 80),

                /// SUBTITLE
                const Text(
                  'Login to continue',
                  style: AppTextStyles.subtitle,
                  textAlign: TextAlign.center,
                ),

                /// GAP: 370 - (256 + 33) ≈ 81
                const Gap(h: 80),

                /// INPUT (52 height already inside widget)
                const GradientTextField(hint: 'Enter Mobile Number or Email'),

                /// GAP: 502 - (370 + 52) ≈ 80
                const Gap(h: 80),

                /// BUTTON (height 50)
                GradientButton(
                  text: 'Continue',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => OtpScreen()),
                    );
                  },
                ),

                const Gap(h: 29),

                /// TERMS
                const Text(
                  'By continuing, you agree to our terms',
                  style: AppTextStyles.caption,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
