import 'package:flutter/material.dart';
import 'package:smgi_connect/features/auth/screens/login_screen_2.dart';
import 'package:smgi_connect/features/auth/widgets/password_field.dart';
import 'package:smgi_connect/features/auth/widgets/password_rule.dart';
import '../../../shared/widgets/auth_background.dart';
import '../../../shared/widgets/gap.dart';
import '../../../shared/widgets/auth/gradient_button.dart';
import '../../../core/constants/app_text_styles.dart';

class PasswordCreationScreen extends StatelessWidget {
  const PasswordCreationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: AuthBackground(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: size.width * 0.06),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// TOP SPACE
                Gap(h: 130),

                /// LOGO
                Center(
                  child: Hero(
                    tag: 'logo',
                    child: RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(
                            text: 'SMGI ',
                            style: AppTextStyles.logoGold,
                          ),
                          TextSpan(
                            text: 'Connect',
                            style: AppTextStyles.logoWhite,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                Gap(h: 84),

                /// TITLE
                const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Create Your Password',
                    style: AppTextStyles.subtitle,
                    textAlign: TextAlign.center,
                  ),
                ),

                const Gap(h: 8),

                /// SUBTITLE
                const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Your safety starts with a strong password.',
                    style: AppTextStyles.body,
                    textAlign: TextAlign.center,
                  ),
                ),
                Gap(h: 26),

                /// PASSWORD
                const Text('Password', style: AppTextStyles.caption),
                const Gap(h: 8),
                const PasswordField(),

                Gap(h: size.height * 0.04),

                /// CONFIRM PASSWORD
                const Text('Confirm Password', style: AppTextStyles.caption),
                const Gap(h: 8),
                const PasswordField(isValid: true),

                Gap(h: 28),

                /// PASSWORD RULES
                const PasswordRule(text: 'At least 8 characters'),
                const PasswordRule(text: 'One uppercase'),
                const PasswordRule(text: 'One number'),
                const PasswordRule(text: 'One special character'),

                Gap(h: 60),

                /// BUTTON
                GradientButton(
                  text: 'Set Password',
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen2()));
                  },
                ),
                const Gap(h: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
