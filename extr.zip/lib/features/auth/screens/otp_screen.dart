import 'package:flutter/material.dart';
import 'package:smgi_connect/features/auth/screens/passsword_creation_screen.dart';
import 'package:smgi_connect/features/auth/widgets/otp_box.dart';
import '../../../shared/widgets/auth_background.dart';
import '../../../shared/widgets/gap.dart';
import '../../../shared/widgets/auth/gradient_button.dart';
import '../../../core/constants/app_text_styles.dart';

class OtpScreen extends StatelessWidget {
  const OtpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: AuthBackground(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: size.width * 0.06),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                /// TOP SPACING (same as login)
                SizedBox(height: size.height * 0.16),

                /// LOGO (Hero animation reused)
                Hero(
                  tag: 'logo',
                  child: RichText(
                    text: const TextSpan(
                      children: [
                        TextSpan(text: 'SMGI ', style: AppTextStyles.logoGold),
                        TextSpan(
                          text: 'Connect',
                          style: AppTextStyles.logoWhite,
                        ),
                      ],
                    ),
                  ),
                ),

                Gap(h: 84),

                /// TITLE
                const Text(
                  'Enter OTP',
                  style: AppTextStyles.subtitle,
                  textAlign: TextAlign.center,
                ),

                const Gap(h: 8),

                /// SUBTITLE
                const Text(
                  'A 4-digit code has been sent to your\nregistered mobile/email.',
                  style: AppTextStyles.body,
                  textAlign: TextAlign.center,
                ),

                Gap(h: 37),

                /// OTP INPUT BOXES
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    OtpBox(),
                    SizedBox(width: 14),
                    OtpBox(),
                    SizedBox(width: 14),
                    OtpBox(),
                    SizedBox(width: 14),
                    OtpBox(),
                  ],
                ),

                Gap(h: 24),

                /// TIMER
                const Text('00:56', style: AppTextStyles.caption),

                const Gap(h: 13),

                /// RESEND OTP
                const Text('Resend OTP', style: AppTextStyles.caption),

                Gap(h: 50),

                /// VERIFY BUTTON
                GradientButton(
                  text: 'Verify Code',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PasswordCreationScreen(),
                      ),
                    );
                    // Dummy action
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
