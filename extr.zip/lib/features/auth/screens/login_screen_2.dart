import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/core/constants/app_text_styles.dart';
import 'package:smgi_connect/features/aadhar/aadhaar_verification_screen.dart';
import 'package:smgi_connect/features/auth/screens/forgot_password_screen.dart';
import 'package:smgi_connect/features/auth/screens/otp_screen_2.dart';
import 'package:smgi_connect/features/navbar/bottom_nav_bar.dart';
import 'package:smgi_connect/shared/widgets/gap.dart';
import 'package:smgi_connect/shared/widgets/auth/gradient_button.dart';
import 'package:smgi_connect/shared/widgets/auth/gradient_text_field.dart';
import 'package:smgi_connect/shared/widgets/auth/plain_text_field.dart';

class LoginScreen2 extends StatelessWidget {
  const LoginScreen2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightGray,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Banner Image
            ClipPath(
              clipper: _BannerClipper(),
              child: Image.asset(
                'assets/images/banner.png',
                width: double.infinity,
                height: 260,
                fit: BoxFit.cover,
              ),
            ),

            const Gap(h: 24),

            // Logo text SMGI Connect
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) {
                    return const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [AppColors.accent, AppColors.black],
                    ).createShader(bounds);
                  },
                  child: const Text('SMGI', style: AppTextStyles.logoGold),
                ),
                const Gap(w: 4),
                const Text('Connect', style: AppTextStyles.logoblack),
              ],
            ),

            const Gap(h: 16),

            // Circular Logo
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: const DecorationImage(
                  image: AssetImage('assets/images/logo.png'),
                  fit: BoxFit.cover,
                ),
                border: Border.all(color: AppColors.white, width: 2),
              ),
            ),

            const Gap(h: 32),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  // Existing field 1
                  const PlainTextField(hint: 'Enter Mobile Number or Email'),

                  const Gap(h: 16),

                  // Existing field 2
                  const PlainTextField(
                    hint: 'Enter password',
                    obscureText: true,
                  ),

                  const Gap(h: 16),

                  // Forgot password
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const AadhaarVerificationScreen(),
                          ),
                        );
                      },
                      child: Text(
                        'Forgotten password?',
                        style: AppTextStyles.caption.copyWith(
                          color: const Color(0xFF094B8A),
                          decoration: TextDecoration.underline,
                          decorationColor: const Color(0xFF094B8A),
                        ),
                      ),
                    ),
                  ),

                  const Gap(h: 24),

                  GradientButton(
                    text: 'Login',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HomeBottomNav(),
                        ),
                      );
                    },
                  ),

                  const Gap(h: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BannerClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height - 50);
    path.quadraticBezierTo(
      size.width / 2,
      size.height,
      size.width,
      size.height - 50,
    );
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
