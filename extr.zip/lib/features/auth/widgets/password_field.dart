import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/core/constants/app_sizes.dart';
import 'package:smgi_connect/core/constants/app_text_styles.dart';

class PasswordField extends StatelessWidget {
  final bool isValid;

  const PasswordField({super.key, this.isValid = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [Color(0xFF11305C), Color(0xFF0E1F39)],
        ),
        borderRadius: BorderRadius.circular(AppSizes.radius),
        border: Border.all(color: const Color(0xFF1259A6), width: 1.2),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          /// LEFT ICON
          Icon(
            isValid ? Icons.check_circle : Icons.lock_outline,
            color: isValid ? AppColors.success : AppColors.gray,
            size: 18,
          ),

          const SizedBox(width: 12),

          /// INPUT
          const Expanded(
            child: TextField(
              obscureText: true,
              style: AppTextStyles.caption,
              decoration: InputDecoration(
                hintText: '••••••••',
                border: InputBorder.none,
              ),
            ),
          ),

          /// EYE ICON
          Icon(Icons.visibility_off_outlined, color: AppColors.gray, size: 18),
        ],
      ),
    );
  }
}
