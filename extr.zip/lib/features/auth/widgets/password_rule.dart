import 'package:flutter/material.dart';
import 'package:smgi_connect/core/constants/app_colors.dart';
import 'package:smgi_connect/core/constants/app_text_styles.dart';

class PasswordRule extends StatelessWidget {
  final String text;

  const PasswordRule({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          const Icon(
            Icons.check_circle_outline,
            size: 16,
            color: AppColors.gray,
          ),
          const SizedBox(width: 8),
          Text(text, style: AppTextStyles.condition),
        ],
      ),
    );
  }
}
