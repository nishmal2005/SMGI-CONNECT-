import 'package:flutter/material.dart';
import 'package:smgi_connect/features/navbar/bottom_nav_bar.dart';
import 'package:smgi_connect/model/payment_model.dart';
import 'payment_card.dart';

class PaymentHistoryPage extends StatefulWidget {
  const PaymentHistoryPage({super.key});

  @override
  State<PaymentHistoryPage> createState() => _PaymentHistoryPageState();
}

class _PaymentHistoryPageState extends State<PaymentHistoryPage> {
  TextEditingController searchController = TextEditingController();

  // 📌 Static List (Dummy Data)
  List<PaymentModel> payments = [
    PaymentModel(
      title: "SMGI Finance",
      dateTime: "Feb 21, 2023 at 03:05 pm",
      amount: "₹5,000",
      status: "Success",
    ),
    PaymentModel(
      title: "State Bank",
      dateTime: "Jan 11, 2023 at 01:30 pm",
      amount: "₹3,200",
      status: "Failed",
    ),
    PaymentModel(
      title: "Axis Bank",
      dateTime: "Jan 10, 2023 at 11:10 am",
      amount: "₹1,000",
      status: "Pending",
    ),
    PaymentModel(
      title: "SMGI Finance",
      dateTime: "Dec 31, 2022 at 04:25 pm",
      amount: "₹7,500",
      status: "Success",
    ),
  ];

  // 🔎 Filtered list for search
  List<PaymentModel> filteredPayments = [];

  @override
  void initState() {
    super.initState();
    filteredPayments = payments; // initialize with all items
  }

  // 🔥 Search Functionality
  void _filterSearch(String value) {
    setState(() {
      filteredPayments = payments.where((item) {
        final searchLower = value.toLowerCase();
        return item.title.toLowerCase().contains(searchLower) ||
            item.status.toLowerCase().contains(searchLower) ||
            item.amount.toLowerCase().contains(searchLower);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        child: Column(
          children: [
            // 🔍 WORKING SEARCH FIELD
            Container(
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Color(0xFFE4E4E4), width: 0.75),
                color: Colors.white,
              ),
              child: TextField(
                controller: searchController,
                onChanged: _filterSearch,
                decoration: const InputDecoration(
                  hintText: "Search",
                  prefixIcon: Icon(Icons.search, color: Colors.grey),
                  border: InputBorder.none,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // 📄 FILTERED LIST DISPLAY
            Expanded(
              child: filteredPayments.isEmpty
                  ? const Center(child: Text("No results found"))
                  : ListView.builder(
                      itemCount: filteredPayments.length,
                      itemBuilder: (context, index) {
                        final item = filteredPayments[index];
                        return PaymentCardWidget(
                          title: item.title,
                          dateTime: item.dateTime,
                          amount: item.amount,
                          status: item.status,
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      // 📌 STATIC BOTTOM NAV BAR
      bottomNavigationBar: const HomeBottomNav(),
    );
  }
}
